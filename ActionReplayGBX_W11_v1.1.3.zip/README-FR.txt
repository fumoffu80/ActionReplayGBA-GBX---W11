Action Replay GBX pour Windows 11 — v1.1.3
==========================================

Compatibilité testée : Action Replay GBA/GBX USB VID 05FD / PID DAAE, menu v3.4.

Nouveautés v1.1.3
-----------------
- Bibliothèque PC séparée de la base réellement stockée dans l'Action Replay.
- Les deux bases sont visibles simultanément : PC Jeux | PC Codes | AR Jeux | AR Codes.
- PCDatabase.xpc officiel Datel 3.3 fourni comme bibliothèque initiale.
- Import .xpc vers la bibliothèque PC.
- Transfert d'un jeu entier ou d'un code sélectionné PC -> Action Replay et inversement.
- Fusion des jeux par code maître afin d'éviter les doublons de noms (ex. Pokemon RF / PKMN ROUGE FEU).
- Normalisation correcte du flag (M) : XPC=1, stockage AR v3.x=3.
- Barre d'état détaillée : connexion, espace libre, jeux/codes AR et bibliothèque PC, activité.
- Interface Français / English ; bascule FR <-> EN corrigée et choix mémorisé dans %LOCALAPPDATA%\ActionReplayGBX\settings.ini.
- Editeur manuel : jeu -> codes -> lignes XXXXXXXX YYYYYYYY.
- Lecture/écriture WinUSB, sauvegarde avant écriture et vérification après écriture.

Fonctionnement
--------------
1. Branchez l'Action Replay en USB, insérez-le dans la GBA avec un jeu et allumez la console jusqu'au menu Action Replay.
2. « Lire l'AR » charge la base de la cartouche sans modifier la bibliothèque PC.
3. Les listes PC et Action Replay restent visibles côte à côte en permanence. Importez des .xpc dans la bibliothèque PC ou créez des codes manuellement.
4. Sélectionnez un jeu ou un code dans la partie PC puis utilisez « Ajouter sélection PC -> AR ». L'inverse est possible avec « AR -> PC ».
5. Cliquez sur n'importe quel jeu/code pour l'éditer dans la zone inférieure, puis utilisez « Écrire l'AR » lorsque la base AR est prête.

Données utilisateur
-------------------
%LOCALAPPDATA%\ActionReplayGBX\
  Backups\       sauvegardes automatiques
  Logs\          journal technique
  Library\       bibliothèque PC persistante
  settings.ini   langue
