Action Replay GBX for Windows 11 — v1.1.3
=========================================

Tested hardware: Action Replay GBA/GBX USB VID 05FD / PID DAAE, menu v3.4.

What's new in v1.1.3
--------------------
- PC library is separate from the database physically stored in the Action Replay.
- Both databases stay visible at the same time: PC Games | PC Codes | AR Games | AR Codes.
- The official Datel 3.3 PCDatabase.xpc is included as the initial PC library.
- Import .xpc files into the PC library.
- Transfer a whole game or a selected code from PC -> Action Replay and back.
- Games are matched by master code to avoid duplicate names (e.g. Pokemon RF / PKMN ROUGE FEU).
- Correct (M) flag normalization: XPC=1, AR v3.x storage=3.
- Detailed bottom status: connection, free space, AR/library game and code counts, activity.
- French / English interface with fixed FR <-> EN toggle and persistent language selection.
- Manual editor: game -> codes -> XXXXXXXX YYYYYYYY lines.
- WinUSB read/write, automatic backup before writing and read-back verification.

User data
---------
%LOCALAPPDATA%\ActionReplayGBX\
  Backups\       automatic backups
  Logs\          technical log
  Library\       persistent PC library
  settings.ini   language

Workflow
--------
1. Read AR loads the cartridge database without replacing the PC library.
2. PC and Action Replay lists remain visible side by side.
3. Select a PC game/code and use Add PC selection -> AR, or transfer the other way.
4. The last clicked item is shown in the editor below.
5. Use Write AR only when the Action Replay side is ready.
